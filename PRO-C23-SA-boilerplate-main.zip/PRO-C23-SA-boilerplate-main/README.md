# PRO-C23-SA-boilerplate
boilerplate code for C23
